"""
kerr_analysis.py
================
Kerr (spinning black hole) extension to the gravitational time-dilation
catalogue. For the subset of systems with published continuum-fitting
spin measurements, this script computes:

  1. The Kerr ISCO radius r_ISCO(a*) for a prograde equatorial circular
     orbit, as a function of the dimensionless spin parameter a* = a/M.
  2. The specific energy (redshift/time-dilation factor) of a circular
     orbit at the ISCO, E_tilde = dtau/dt, which generalises the
     Schwarzschild result sqrt(2/3) ~ 0.8165 to spinning black holes.
  3. The corresponding fractional proper-time deficit at the ISCO,
     1 - E_tilde, for prograde orbits.

Units: r is expressed in gravitational radii r_g = GM/c^2 (i.e. M = 1 in
geometrized units), so r_ISCO is dimensionless (ranges from 9 for a*=-1
retrograde extremal, to 6 for a*=0 Schwarzschild, down to 1 for a*=+1
prograde extremal).

Author: Mohammad Saipul Rohman (Independent Researcher, Indonesia)
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def kerr_isco_radius(a_star, prograde=True):
    """
    Bardeen, Press & Teukolsky (1972) ISCO radius for the Kerr metric,
    in units of r_g = GM/c^2.

    Parameters
    ----------
    a_star : float or array
        Dimensionless spin parameter, -1 <= a_star <= 1.
    prograde : bool
        If True, compute the prograde (co-rotating) ISCO; if False,
        the retrograde (counter-rotating) ISCO.

    Returns
    -------
    r_isco : float or array
        ISCO radius in units of r_g.
    """
    a = np.asarray(a_star, dtype=float)
    sign = 1.0 if prograde else -1.0

    Z1 = 1 + (1 - a**2) ** (1 / 3) * ((1 + a) ** (1 / 3) + (1 - a) ** (1 / 3))
    Z2 = np.sqrt(3 * a**2 + Z1**2)

    r_isco = 3 + Z2 - sign * np.sqrt((3 - Z1) * (3 + Z1 + 2 * Z2))
    return r_isco


def kerr_circular_orbit_energy(r, a_star, prograde=True):
    """
    Specific energy (per unit rest mass) of a circular equatorial
    geodesic orbit in the Kerr metric, E_tilde = -u_t.

    For a circular orbit, E_tilde equals the time-dilation factor
    dtau/dt of the orbiting observer relative to a distant static
    observer (the gravitational + orbital-velocity redshift combined).

    Parameters
    ----------
    r : float or array
        Orbital radius in units of r_g = GM/c^2.
    a_star : float or array
        Dimensionless spin parameter.
    prograde : bool
        Orbit sense.

    Returns
    -------
    E_tilde : float or array
        dtau/dt for the circular orbit at radius r.
    """
    r = np.asarray(r, dtype=float)
    a = np.asarray(a_star, dtype=float)
    sign = 1.0 if prograde else -1.0

    numerator = r ** 1.5 - 2 * r ** 0.5 + sign * a
    denom_term = r ** 1.5 - 3 * r ** 0.5 + sign * 2 * a
    # Numerical safeguard: at r = r_ISCO this term is exactly zero in exact
    # arithmetic but can go slightly negative due to floating-point error,
    # which would make the sqrt undefined. Clip to a small positive floor.
    denom_term = np.clip(denom_term, 1e-12, None)
    denominator = r ** 0.75 * np.sqrt(denom_term)
    return numerator / denominator


# ----------------------------------------------------------------------
# Load spin subset
# ----------------------------------------------------------------------
df = pd.read_csv("data/spin_subset.csv")

# ----------------------------------------------------------------------
# Compute Kerr ISCO radius and time-dilation factor at the ISCO
# ----------------------------------------------------------------------
df["r_isco_rg"] = kerr_isco_radius(df["a_star"], prograde=True)
df["E_tilde_isco"] = kerr_circular_orbit_energy(
    df["r_isco_rg"], df["a_star"], prograde=True
)
df["isco_lag_fraction"] = 1 - df["E_tilde_isco"]
df["isco_lag_pct"] = df["isco_lag_fraction"] * 100

# Schwarzschild reference values (a* = 0): the circular-orbit specific
# energy at the ISCO (r = 6 r_g) is E_tilde = sqrt(8/9) ~ 0.9428. This is
# DIFFERENT from sqrt(2/3) ~ 0.8165, which is the *static-observer*
# redshift factor sqrt(1-Rs/r) used in the main paper's Eq. (2)-(3). The
# two differ because E_tilde additionally includes the orbital-velocity
# (special-relativistic) contribution of the circularly orbiting observer.
r0 = 6.0
a0 = 0.0
E0 = kerr_circular_orbit_energy(r0, a0, prograde=True)

# ----------------------------------------------------------------------
# Monte Carlo propagation: spin uncertainty -> ISCO lag uncertainty
# ----------------------------------------------------------------------
rng = np.random.default_rng(42)
N_MC = 200_000

mc_results = []
for _, row in df.iterrows():
    a_samples = rng.normal(
        loc=row["a_star"],
        scale=(row["a_star_err_minus"] + row["a_star_err_plus"]) / 2,
        size=N_MC,
    )
    # Clip to physical range
    a_samples = np.clip(a_samples, -0.9999, 0.9999)

    r_isco_samples = kerr_isco_radius(a_samples, prograde=True)
    E_samples = kerr_circular_orbit_energy(r_isco_samples, a_samples, prograde=True)
    lag_samples = (1 - E_samples) * 100  # percent

    mc_results.append({
        "common_name": row["common_name"],
        "isco_lag_pct_median": np.median(lag_samples),
        "isco_lag_pct_p16": np.percentile(lag_samples, 16),
        "isco_lag_pct_p84": np.percentile(lag_samples, 84),
        "r_isco_rg_median": np.median(r_isco_samples),
    })

mc_df = pd.DataFrame(mc_results)
df = df.merge(mc_df, on="common_name")

# ----------------------------------------------------------------------
# Save results
# ----------------------------------------------------------------------
out_cols = [
    "common_name", "Mx_solar", "a_star", "a_star_err_minus", "a_star_err_plus",
    "r_isco_rg", "E_tilde_isco", "isco_lag_pct",
    "isco_lag_pct_median", "isco_lag_pct_p16", "isco_lag_pct_p84",
    "a_star_method", "reference",
]
df[out_cols].to_csv("data/kerr_isco_results.csv", index=False)
print(df[out_cols].to_string(index=False))
print(f"\nSchwarzschild reference (a*=0): r_ISCO = {r0:.3f} r_g, "
      f"E_tilde = {E0:.4f}, lag = {(1-E0)*100:.3f}%")

# ----------------------------------------------------------------------
# Figure: ISCO lag (%) vs spin parameter a*, with curve + data points
# ----------------------------------------------------------------------
a_grid = np.linspace(0.0, 0.998, 400)
r_isco_grid = kerr_isco_radius(a_grid, prograde=True)
E_grid = kerr_circular_orbit_energy(r_isco_grid, a_grid, prograde=True)
lag_grid = (1 - E_grid) * 100

fig, ax = plt.subplots(figsize=(7, 5.2))
ax.plot(a_grid, lag_grid, color="#333333", lw=1.8,
        label=r"Prograde ISCO, $1-\tilde{E}_{\rm ISCO}$")

ax.axvline(0, color="gray", ls=":", lw=1)
ax.axhline((1 - E0) * 100, color="gray", ls=":", lw=1)
ax.annotate("Schwarzschild ($a_*=0$)", xy=(0, (1 - E0) * 100),
             xytext=(0.08, (1 - E0) * 100 + 2.5), fontsize=8, color="gray",
             arrowprops=dict(arrowstyle="->", color="gray", lw=0.8))

colors = plt.cm.viridis(np.linspace(0.1, 0.9, len(df)))
for (_, row), col in zip(df.iterrows(), colors):
    ax.errorbar(
        row["a_star"], row["isco_lag_pct_median"],
        yerr=[[row["isco_lag_pct_median"] - row["isco_lag_pct_p16"]],
              [row["isco_lag_pct_p84"] - row["isco_lag_pct_median"]]],
        xerr=[[row["a_star_err_minus"]], [row["a_star_err_plus"]]],
        fmt="o", color=col, markersize=8, capsize=3,
        label=row["common_name"],
    )

ax.set_xlabel(r"Dimensionless spin parameter, $a_* = a/M$")
ax.set_ylabel(r"Proper-time deficit at ISCO, $1-\tilde{E}_{\rm ISCO}$ [%]")
ax.set_title("Gravitational time dilation at the ISCO\nfor spinning (Kerr) black holes")
ax.legend(fontsize=8, loc="upper left")
ax.grid(True, ls=":", alpha=0.4)
ax.set_xlim(-0.05, 1.02)
fig.tight_layout()
fig.savefig("figures/figure3.png", dpi=300)
plt.close(fig)

print("\nDone. Results written to data/kerr_isco_results.csv")
print("Figure written to figures/figure3.png")
