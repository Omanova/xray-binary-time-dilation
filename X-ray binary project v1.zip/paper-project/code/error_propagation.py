"""
error_propagation.py
=====================
Monte Carlo propagation of observational uncertainties in M_X, M_d,
P_orb, and d through the time-dilation formalism of Section 3 of the
main paper, to obtain credible intervals on Delta_1000 (fixed-altitude
gravitational lag) and Delta_tot (total donor-star time-dilation
fraction) for all 18 systems in the sample.

Orbital period is taken as exact (negligible relative uncertainty for
all systems). Distance uncertainty does not enter Delta_1000 or
Delta_tot directly (both are mass/period-based quantities and do not
depend on distance), but is retained in the dataset for completeness
and potential use in future flux-based analyses.

For systems without a published M_X uncertainty (all neutron stars with
the canonical 1.4 Msun assumption), we adopt a 1-sigma uncertainty of
0.2 Msun, consistent with the scatter seen in dynamically measured
neutron-star masses in LMXBs (Galloway et al. 2008). Donor masses
without published uncertainties are assigned a fractional uncertainty
of 15%.

Author: Mohammad Saipul Rohman (Independent Researcher, Indonesia)
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Physical constants (SI)
G = 6.67430e-11
c = 2.99792458e8
M_sun = 1.98847e30
day_s = 86400.0
yr_s = 365.25 * day_s

rng = np.random.default_rng(12345)
N_MC = 100_000

df = pd.read_csv("data/dataset.csv")

# Default donor-mass uncertainty (15%) where not otherwise specified
DONOR_MASS_FRAC_ERR = 0.15

# Default compact-object mass uncertainty for canonical 1.4 Msun NS
DEFAULT_NS_MX_ERR = 0.2

results = []

for _, row in df.iterrows():
    Mx0 = row["Mx_solar"]
    Mx_err = row["Mx_err_solar"] if not np.isnan(row["Mx_err_solar"]) else DEFAULT_NS_MX_ERR
    Md0 = row["donor_mass_solar"]
    Md_err = Md0 * DONOR_MASS_FRAC_ERR
    P_orb = row["orbital_period_days"] * day_s  # treated as exact

    # Sample masses from (truncated) normal distributions, requiring
    # positivity.
    Mx_samples = rng.normal(Mx0, Mx_err, N_MC)
    Mx_samples = np.clip(Mx_samples, 0.05, None)
    Md_samples = rng.normal(Md0, Md_err, N_MC)
    Md_samples = np.clip(Md_samples, 1e-3, None)

    # --- Delta_1000: fixed-altitude gravitational lag ---
    Mx_kg = Mx_samples * M_sun
    Rs = 2 * G * Mx_kg / c**2
    r_probe = Rs + 1.0e6
    dtau_dt = np.sqrt(np.clip(1 - Rs / r_probe, 0, 1))
    delta_1000_ppm = (1 - dtau_dt) * 1e6

    # --- Delta_tot: total donor-star time dilation ---
    M_tot_kg = (Mx_samples + Md_samples) * M_sun
    a_rel = (G * M_tot_kg * P_orb**2 / (4 * np.pi**2)) ** (1 / 3)
    a_donor = a_rel * (Mx_samples / (Mx_samples + Md_samples))
    v_donor = 2 * np.pi * a_donor / P_orb
    v_over_c = v_donor / c

    sr_lag = 1 - np.sqrt(np.clip(1 - v_over_c**2, 0, 1))
    grav_lag = G * Mx_kg / (a_donor * c**2)
    total_lag_ppm = (sr_lag + grav_lag) * 1e6

    results.append({
        "common_name": row["common_name"],
        "compact_object_type": row["compact_object_type"],
        # Delta_1000 statistics
        "delta1000_median": np.median(delta_1000_ppm),
        "delta1000_p16": np.percentile(delta_1000_ppm, 16),
        "delta1000_p84": np.percentile(delta_1000_ppm, 84),
        # Delta_tot statistics
        "deltatot_median": np.median(total_lag_ppm),
        "deltatot_p16": np.percentile(total_lag_ppm, 16),
        "deltatot_p84": np.percentile(total_lag_ppm, 84),
        "deltatot_rel_err_pct": 100 * (np.percentile(total_lag_ppm, 84)
                                        - np.percentile(total_lag_ppm, 16))
                                / (2 * np.median(total_lag_ppm)),
    })

mc_df = pd.DataFrame(results)
mc_df.to_csv("data/monte_carlo_results.csv", index=False)
print(mc_df.to_string(index=False))

# ----------------------------------------------------------------------
# Figure: Delta_tot with 68% credible intervals, sorted by median value
# ----------------------------------------------------------------------
mc_sorted = mc_df.sort_values("deltatot_median", ascending=True).reset_index(drop=True)

colors = {"Black Hole": "#7b2cbf", "Neutron Star": "#1f77b4"}

fig, ax = plt.subplots(figsize=(7, 6.5))
y_pos = np.arange(len(mc_sorted))

for i, row in mc_sorted.iterrows():
    ax.errorbar(
        row["deltatot_median"], i,
        xerr=[[row["deltatot_median"] - row["deltatot_p16"]],
              [row["deltatot_p84"] - row["deltatot_median"]]],
        fmt="o", color=colors[row["compact_object_type"]],
        markersize=6, capsize=3, elinewidth=1.2,
    )

ax.set_yticks(y_pos)
ax.set_yticklabels(mc_sorted["common_name"], fontsize=8)
ax.set_xscale("log")
ax.set_xlabel(r"Total donor-star time dilation, $\Delta_{\rm tot}$ [ppm]")
ax.set_title("Monte Carlo 68% credible intervals on $\\Delta_{\\rm tot}$\n"
              "(propagating uncertainties in $M_X$, $M_d$)")
ax.grid(True, axis="x", which="both", ls=":", alpha=0.4)

from matplotlib.lines import Line2D
legend_elems = [
    Line2D([0], [0], marker="o", color="w", markerfacecolor=colors["Black Hole"],
           markersize=8, label="Black Hole"),
    Line2D([0], [0], marker="o", color="w", markerfacecolor=colors["Neutron Star"],
           markersize=8, label="Neutron Star"),
]
ax.legend(handles=legend_elems, fontsize=9, loc="lower right")

fig.tight_layout()
fig.savefig("figures/figure4.png", dpi=300)
plt.close(fig)

print("\nDone. Results written to data/monte_carlo_results.csv")
print("Figure written to figures/figure4.png")
