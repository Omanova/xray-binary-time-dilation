"""
analysis.py
============
Gravitational and orbital-velocity time dilation analysis for a sample of
Galactic X-ray binary systems (black-hole and neutron-star LMXBs/HMXBs).

For each system, this script computes:
  1. The Schwarzschild radius R_s of the compact object.
  2. The gravitational time dilation factor at the inner-most stable
     circular orbit (ISCO), 3 R_s for a non-rotating (Schwarzschild) BH/NS.
  3. The orbital (special-relativistic) time dilation factor of the donor
     star, derived from Kepler's third law using the total system mass,
     orbital period, and component masses.
  4. The combined (total) proper-time lag per orbit and per year, expressed
     in seconds, for an observer co-orbiting at the donor's semi-major axis
     versus a distant static observer.

Output: data/derived_quantities.csv, figures/figure1.png, figures/figure2.pdf

Author: Mohammad Saipul Rohman (Independent Researcher, Indonesia)
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ----------------------------------------------------------------------
# Physical constants (SI units)
# ----------------------------------------------------------------------
G = 6.67430e-11          # m^3 kg^-1 s^-2
c = 2.99792458e8         # m/s
M_sun = 1.98847e30       # kg
day_s = 86400.0          # seconds per day
yr_s = 365.25 * day_s    # seconds per Julian year

# ----------------------------------------------------------------------
# Load dataset
# ----------------------------------------------------------------------
df = pd.read_csv("data/dataset.csv")

# ----------------------------------------------------------------------
# Derived quantity calculations
# ----------------------------------------------------------------------

# 1. Schwarzschild radius of the compact object [m] and [km]
df["Mx_kg"] = df["Mx_solar"] * M_sun
df["Rs_m"] = 2 * G * df["Mx_kg"] / c**2
df["Rs_km"] = df["Rs_m"] / 1e3

# 2. ISCO radius (non-spinning Schwarzschild case): r_ISCO = 6 GM/c^2 = 3 Rs
df["R_isco_m"] = 3 * df["Rs_m"]
df["R_isco_km"] = df["R_isco_m"] / 1e3

# 3. Gravitational time dilation factor at the ISCO, relative to a distant
#    observer:  dτ/dt = sqrt(1 - Rs/r). At r = 3 Rs this reduces to the
#    universal, mass-independent value sqrt(2/3) for any Schwarzschild BH.
df["grav_dilation_ISCO"] = np.sqrt(1 - df["Rs_m"] / df["R_isco_m"])

# Fractional gravitational time lag at the ISCO (dimensionless), in parts
# per million (ppm) and seconds lost per year for a clock parked there.
df["grav_lag_fraction_ISCO"] = 1 - df["grav_dilation_ISCO"]
df["grav_lag_ppm_ISCO"] = df["grav_lag_fraction_ISCO"] * 1e6
df["grav_lag_s_per_yr_ISCO"] = df["grav_lag_fraction_ISCO"] * yr_s

# 3b. Gravitational time dilation evaluated at a FIXED physical altitude of
#     1000 km above the compact-object surface scale (r = Rs + 1000 km).
#     This quantity *does* vary with mass and illustrates how close a probe
#     could approach before extreme dilation sets in for objects of very
#     different compactness.
r_probe_m = df["Rs_m"] + 1.0e6  # Rs + 1000 km, in meters
df["grav_dilation_probe_1000km"] = np.sqrt(np.clip(1 - df["Rs_m"] / r_probe_m, 0, 1))
df["grav_lag_fraction_probe"] = 1 - df["grav_dilation_probe_1000km"]
df["grav_lag_ppm_probe_1000km"] = df["grav_lag_fraction_probe"] * 1e6
df["probe_lag_days_per_century"] = df["grav_lag_fraction_probe"] * (100 * yr_s) / day_s

# 4. Orbital semi-major axis of the donor star around the system barycenter,
#    derived from Kepler's third law applied to the *relative* orbit, then
#    scaled by mass ratio to the donor's orbit about the barycenter.
df["M_total_kg"] = (df["Mx_solar"] + df["donor_mass_solar"]) * M_sun
df["P_orb_s"] = df["orbital_period_days"] * day_s

# Relative semi-major axis (separation) a_rel via Kepler III:
# P^2 = 4 pi^2 a_rel^3 / (G M_total)
df["a_rel_m"] = (G * df["M_total_kg"] * df["P_orb_s"]**2 / (4 * np.pi**2)) ** (1.0/3.0)

# Donor's orbital radius about the barycenter: a_donor = a_rel * Mx/(Mx+Md)
df["a_donor_m"] = df["a_rel_m"] * (df["Mx_solar"] / (df["Mx_solar"] + df["donor_mass_solar"]))

# Donor orbital (circular-orbit) speed: v = 2 pi a_donor / P
df["v_donor_ms"] = 2 * np.pi * df["a_donor_m"] / df["P_orb_s"]
df["v_donor_over_c"] = df["v_donor_ms"] / c

# Special-relativistic time dilation factor for the donor's orbital motion:
# dτ/dt = sqrt(1 - v^2/c^2)
df["sr_dilation_donor"] = np.sqrt(1 - df["v_donor_over_c"]**2)
df["sr_lag_fraction_donor"] = 1 - df["sr_dilation_donor"]
df["sr_lag_ppm_donor"] = df["sr_lag_fraction_donor"] * 1e6
df["sr_lag_s_per_yr_donor"] = df["sr_lag_fraction_donor"] * yr_s

# 5. Gravitational time dilation experienced by the donor star itself, due
#    to the compact object's potential at the donor's orbital distance
#    (weak-field approximation, Phi/c^2 = GM/(r c^2), valid since a_donor >> Rs)
df["grav_potential_donor"] = G * df["Mx_kg"] / (df["a_donor_m"] * c**2)
df["grav_lag_fraction_donor"] = df["grav_potential_donor"]  # weak-field: dτ/dt ≈ 1 - GM/(rc^2)
df["grav_lag_ppm_donor"] = df["grav_lag_fraction_donor"] * 1e6
df["grav_lag_s_per_yr_donor"] = df["grav_lag_fraction_donor"] * yr_s

# 6. Combined (total) proper-time lag for the donor star per year, i.e. how
#    much slower the donor's clock runs relative to a distant static
#    observer due to BOTH special-relativistic (orbital velocity) and
#    general-relativistic (gravitational potential) effects (weak field,
#    additive to leading order).
df["total_lag_fraction_donor"] = df["sr_lag_fraction_donor"] + df["grav_lag_fraction_donor"]
df["total_lag_ppm_donor"] = df["sr_lag_ppm_donor"] + df["grav_lag_ppm_donor"]
df["total_lag_s_per_yr_donor"] = df["total_lag_fraction_donor"] * yr_s
df["total_lag_hours_per_century"] = df["total_lag_fraction_donor"] * (100 * yr_s) / 3600.0

# ----------------------------------------------------------------------
# Save derived quantities table
# ----------------------------------------------------------------------
out_cols = [
    "system_id", "common_name", "compact_object_type",
    "Mx_solar", "Rs_km", "R_isco_km",
    "grav_lag_ppm_ISCO",
    "grav_lag_ppm_probe_1000km", "probe_lag_days_per_century",
    "a_rel_m", "a_donor_m", "v_donor_over_c",
    "sr_lag_ppm_donor", "grav_lag_ppm_donor",
    "total_lag_ppm_donor", "total_lag_hours_per_century",
]
derived = df[out_cols].copy()
derived.to_csv("data/derived_quantities.csv", index=False)
print(derived.to_string(index=False))

# ----------------------------------------------------------------------
# Figure 1: Total donor-star time dilation (ppm) vs compact-object mass,
# color-coded by compact object type, marker size by orbital period.
# ----------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7, 5.2))

colors = {"Black Hole": "#7b2cbf", "Neutron Star": "#1f77b4"}
markers = {"Black Hole": "o", "Neutron Star": "^"}

for obj_type, sub in df.groupby("compact_object_type"):
    ax.scatter(
        sub["Mx_solar"], sub["total_lag_ppm_donor"],
        s=60 + 10 * np.log10(sub["orbital_period_days"] * 24 + 1) * 15,
        c=colors[obj_type], marker=markers[obj_type],
        label=obj_type, alpha=0.8, edgecolors="k", linewidths=0.5,
    )

for _, row in df.iterrows():
    ax.annotate(
        row["common_name"], (row["Mx_solar"], row["total_lag_ppm_donor"]),
        fontsize=6.5, xytext=(4, 4), textcoords="offset points"
    )

ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlabel(r"Compact object mass $M_X$ [$M_\odot$]")
ax.set_ylabel(r"Total donor-star time dilation, $\Delta\tau/\tau$ [ppm]")
ax.set_title("Combined gravitational + orbital time dilation of the\ndonor star in Galactic X-ray binaries")
ax.legend(frameon=True, fontsize=9)
ax.grid(True, which="both", ls=":", alpha=0.4)
fig.tight_layout()
fig.savefig("figures/figure1.png", dpi=300)
plt.close(fig)

# ----------------------------------------------------------------------
# Figure 2: Gravitational time-dilation lag (days per century) for a probe
# held at a fixed altitude of 1000 km above each compact object's
# Schwarzschild radius, vs compact-object mass, log-log, by object type.
# ----------------------------------------------------------------------
fig2, ax2 = plt.subplots(figsize=(7, 5.2))

for obj_type, sub in df.groupby("compact_object_type"):
    ax2.scatter(
        sub["Mx_solar"], sub["probe_lag_days_per_century"],
        c=colors[obj_type], marker=markers[obj_type],
        s=70, label=obj_type, alpha=0.85, edgecolors="k", linewidths=0.5,
    )

for _, row in df.iterrows():
    ax2.annotate(
        row["common_name"], (row["Mx_solar"], row["probe_lag_days_per_century"]),
        fontsize=6.5, xytext=(4, 4), textcoords="offset points"
    )

ax2.set_xscale("log")
ax2.set_yscale("log")
ax2.set_xlabel(r"Compact object mass $M_X$ [$M_\odot$]")
ax2.set_ylabel("Gravitational time lag at 1000 km altitude\nabove $R_s$ [days per century]")
ax2.set_title("Proper-time lag for a probe held 1000 km above the\nSchwarzschild radius of each compact object")
ax2.legend(frameon=True, fontsize=9)
ax2.grid(True, which="both", ls=":", alpha=0.4)
fig2.tight_layout()
fig2.savefig("figures/figure2.pdf")
plt.close(fig2)

print("\nDone. Derived table written to data/derived_quantities.csv")
print("Figures written to figures/figure1.png and figures/figure2.pdf")
