# A Comparative Catalogue of Gravitational and Orbital Time-Dilation Effects in Galactic X-ray Binary Systems

**Author:** Mohammad Saipul Rohman
**Affiliation:** Independent Researcher, Indonesia
**Contact:** saifulrohmanyo@gmail.com

## Overview

This repository contains the manuscript, dataset, analysis code, and
figures for a study quantifying gravitational and orbital
time-dilation effects in a sample of 18 well-characterised Galactic
X-ray binary systems (9 black-hole and 9 neutron-star systems,
predominantly low-mass X-ray binaries together with a few intermediate-
and high-mass systems), using published dynamical masses, orbital
periods, and distances.

For each system we compute:

1. The Schwarzschild radius $R_s$ of the compact object.
2. The gravitational time-dilation factor for a notional probe held at
   a fixed altitude of 1000 km above $R_s$.
3. The combined special- and general-relativistic time dilation
   experienced by the donor star due to its orbital velocity and its
   position in the compact object's gravitational potential.

For a subset of five black holes with published continuum-fitting spin
measurements, we additionally compute:

4. The Kerr ISCO radius and the spin-dependent proper-time deficit for
   matter in a circular orbit at the ISCO (Bardeen-Press-Teukolsky
   formalism), with Monte Carlo propagation of spin uncertainties.

For all 18 systems, we further perform:

5. A Monte Carlo propagation of mass uncertainties ($M_X$, $M_d$) to
   obtain 68% credible intervals on $\Delta_{1000}$ and
   $\Delta_{\rm tot}$.

## Repository structure

```
paper-project/
├── manuscript.tex        # Main LaTeX source
├── references.bib        # Bibliography (BibTeX)
├── paper.pdf             # Compiled PDF of the manuscript
├── README.md             # This file
├── LICENSE               # License terms
│
├── figures/
│   ├── figure1.png         # Donor-star time dilation vs compact-object mass
│   ├── figure2.pdf          # Fixed-altitude gravitational lag vs mass
│   ├── figure3.png          # Kerr ISCO proper-time deficit vs spin parameter
│   └── figure4.png          # Monte Carlo credible intervals for Delta_tot
│
├── data/
│   ├── dataset.csv               # Input dynamical parameters (18 systems)
│   ├── derived_quantities.csv    # Derived relativistic quantities
│   ├── spin_subset.csv           # BH spin measurements (5 systems)
│   ├── kerr_isco_results.csv     # Kerr ISCO time-dilation results
│   └── monte_carlo_results.csv   # MC credible intervals (Delta_1000, Delta_tot)
│
├── code/
│   ├── analysis.py            # Main analysis script (Schwarzschild, Sections 3.1-3.3)
│   ├── kerr_analysis.py        # Kerr ISCO + spin analysis (Section 3.4)
│   ├── error_propagation.py    # Monte Carlo uncertainty propagation (Section 3.5)
│   └── notebook.ipynb           # Interactive Jupyter notebook version
│
└── supplementary/
    └── appendix.pdf        # Full input table + worked example (Cygnus X-1)
```

## Reproducing the results

The analysis requires Python 3 with `numpy`, `pandas`, and
`matplotlib`. From the repository root:

```bash
python3 code/analysis.py
python3 code/kerr_analysis.py
python3 code/error_propagation.py
```

These scripts read `data/dataset.csv` and `data/spin_subset.csv`, write
`data/derived_quantities.csv`, `data/kerr_isco_results.csv`, and
`data/monte_carlo_results.csv`, and regenerate `figures/figure1.png`
through `figures/figure4.png`.

To compile the manuscript from source:

```bash
pdflatex manuscript.tex
bibtex manuscript
pdflatex manuscript.tex
pdflatex manuscript.tex
```

## Data sources

All input parameters are drawn from the published literature,
principally:

- Casares & Jonker (2014), *Space Science Reviews*, 183, 223
- Liu, van Paradijs & van den Heuvel (2007), *A&A*, 469, 807
- Corral-Santana et al. (2016, BlackCAT), *A&A*, 587, A61
- Fortin et al. (2024), *A&A* (INTEGRAL/Gaia-era LMXB catalogue)
- Avakyan et al. (2023, XRBcats), arXiv:2303.16168
- Miller-Jones et al. (2021), *Science*, 371, 1046 (Cygnus X-1 mass)
- Galloway et al. (2008), *ApJS*, 179, 360 (neutron-star LMXB sample)

Black-hole spin measurements (Section 3.4/4.4) are drawn from:

- Shafee et al. (2006), *ApJL*, 636, L113 (GRO J1655-40, 4U 1543-475)
- McClintock et al. (2006), *ApJ*, 652, 518 (GRS 1915+105)
- Gou et al. (2010), *ApJ*, 718, 620 (A0620-00 spin methodology)
- Gou et al. (2011), *ApJ*, 742, 85 (Cygnus X-1)
- Zhao et al. (2021), *ApJ*, 916, 108 (Cygnus X-1, re-estimate)

Full references are provided in `references.bib`.

## License

See `LICENSE` for terms.
